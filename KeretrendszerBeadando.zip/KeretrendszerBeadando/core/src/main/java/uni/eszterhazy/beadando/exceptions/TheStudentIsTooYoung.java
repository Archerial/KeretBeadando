package uni.eszterhazy.beadando.exceptions;

public class TheStudentIsTooYoung extends Throwable {
    public TheStudentIsTooYoung(String s) {
        super(s);
    }
}
