package uni.eszterhazy.beadando.model;

public enum Department {
    CS,BI,TM,ITL
    //CS:Computer Sience, BI: Bussines Informatics, TM: Teacher Major, ITL: IT Librarian
}
