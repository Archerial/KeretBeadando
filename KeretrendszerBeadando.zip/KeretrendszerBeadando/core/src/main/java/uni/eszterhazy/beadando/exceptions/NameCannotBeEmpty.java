package uni.eszterhazy.beadando.exceptions;

public class NameCannotBeEmpty extends Throwable {

}
