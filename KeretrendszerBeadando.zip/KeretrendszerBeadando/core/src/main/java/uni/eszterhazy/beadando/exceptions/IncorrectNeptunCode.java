package uni.eszterhazy.beadando.exceptions;

public class IncorrectNeptunCode extends Throwable {
}
