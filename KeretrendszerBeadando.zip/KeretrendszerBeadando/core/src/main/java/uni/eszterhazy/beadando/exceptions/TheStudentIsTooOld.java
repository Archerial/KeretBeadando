package uni.eszterhazy.beadando.exceptions;

public class TheStudentIsTooOld extends Throwable {
    public TheStudentIsTooOld(String s) {
        super(s);
    }
}
